package first_basics;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class Application extends JFrame {

    public Application() {

        initUI();
    }

    private void initUI() {

        //initializes what is in the window
        add(new Board());

        //sets size of window
        setSize(250, 200);

        //set title of window(text across the top)
        setTitle("basics.Application");

        //allows for ending program by pressing the X
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //centers window
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {
            Application ex = new Application();
            ex.setVisible(true);
        });
    }
}