package first_basics;

import javax.swing.JPanel;

public class Board extends JPanel {

    //put what happens in here.
    public Board() {}
}